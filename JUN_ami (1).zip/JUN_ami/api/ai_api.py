import openai

openai.api