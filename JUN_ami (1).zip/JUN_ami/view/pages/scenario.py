import streamlit as st
import time
from view.ui.bg import bg2, bg_cl  # type: ignore

TIME_LIMIT = 45  # 제한 시간 (초)
MAX_LENGTH = 140  # 최대 글자 수 제한

def a3():
    bg_cl()
    bg2("https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExNmpqMmZjbXhhNjNqY2NnZjh0OTI2bGVtNzFldGh6c3Fkamh0emVkMiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/PNQi3nT7CVE3JFiRot/giphy.gif")

    # 상태 초기화
    if "start_time" not in st.session_state:
        st.session_state.start_time = time.time()
    if "scenario_phase" not in st.session_state:
        st.session_state.scenario_phase = "input"
    if "user_input" not in st.session_state:
        st.session_state.user_input = ""

    elapsed = int(time.time() - st.session_state.start_time)
    remaining = max(0, TIME_LIMIT - elapsed)

    # 깜빡임 스타일 정의
    st.markdown("""
    <style>
    @keyframes blink {
        0% { opacity: 1; }
        100% { opacity: 0.4; }
    }
    .blinking-bar {
        animation: blink 1s infinite alternate;
    }
    </style>
    """, unsafe_allow_html=True)

    # === 단계별 흐름 처리 ===

    # 1. 전송 메시지 표시
    if st.session_state.scenario_phase == "sending":
        st.markdown("<h1 style='text-align: center; color: black;'>시나리오가 오고 있습니다.</h1>", unsafe_allow_html=True)
        time.sleep(3)
        st.session_state.scenario_phase = "prepare"
        st.rerun()

    # 2. 준비 메시지 표시
    elif st.session_state.scenario_phase == "prepare":
        st.markdown("<h1 style='text-align: center; color: black;'>준비하세요!</h1>", unsafe_allow_html=True)
        time.sleep(3)
        st.session_state.page = "prompf"
        st.session_state.scenario_phase = "input"
        st.rerun()

    # 3. 입력 화면
    elif st.session_state.scenario_phase == "input":
        percent = int((remaining / TIME_LIMIT) * 100)
        blink_class = "blinking-bar" if remaining < 10 else ""
        bar_html = f"""
        <div style="background-color:#eee; border-radius:10px; height:20px; width:100%; margin-bottom: 20px;">
            <div class="{blink_class}" style="
                width:{percent}% ;
                background-color:#ff4d4d;
                height:100%;
                border-radius:10px;
                transition: width 1s linear;
            "></div>
        </div>
        """
        st.markdown(bar_html, unsafe_allow_html=True)

        st.markdown("<h2 style='text-align: center; color: black;'>시나리오를 작성하세요.</h2>", unsafe_allow_html=True)
        st.markdown(f"<h1 style='text-align: center; font-size: 72px; color: black;'>{remaining}</h1>", unsafe_allow_html=True)

        st.session_state.user_input = st.text_area("", value=st.session_state.user_input, max_chars=MAX_LENGTH)
        char_count = len(st.session_state.user_input)
        st.markdown(
            f"<div style='text-align: right; font-size: 14px; color: #888;'>{char_count} / {MAX_LENGTH}자</div>",
            unsafe_allow_html=True
        )

        if st.button("제출"):
            if st.session_state.user_input.strip():
                st.session_state.scenario_phase = "sending"
                st.rerun()

        if remaining == 0 and not st.session_state.user_input.strip():
            st.session_state.page = "result"
            st.rerun()

        if remaining > 0:
            time.sleep(1)
            st.rerun()