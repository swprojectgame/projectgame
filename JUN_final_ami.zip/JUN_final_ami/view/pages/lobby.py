import streamlit as st
from view.ui.bg import bg # type: ignore

def a2():
    bg()  
    st.title("ㅁㄴㅇㅀㄴㅁㅇㄹ")

    if st.button("참가"):
        st.session_state.page = "scenario"

import streamlit as st
from view.ui.bg import bg  # type: ignore

def a2():
    bg()

    # 플레이어 이름 불러오기
    name = st.session_state.get("player_name", "플레이어")

    # 타이틀 표시 (필요 시 사용자 이름 포함 가능)
    st.markdown(f"<h1 style='color: white;'>환영합니다, {name}!</h1>", unsafe_allow_html=True)

    # 참가 버튼 → 시나리오로 이동
    if st.button("참가"):
        st.session_state.page = "scenario"
        st.rerun()