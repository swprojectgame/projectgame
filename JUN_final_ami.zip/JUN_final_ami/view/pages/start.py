import streamlit as st
from view.ui.bg import bg  # type: ignore

def a1():
    bg()

    # 상태 초기화
    if "name_input_mode" not in st.session_state:
        st.session_state.name_input_mode = False

    # 참가 버튼 누르기 전
    if not st.session_state.name_input_mode:
        st.markdown("<h1 style='color: white;'>AMI</h1>", unsafe_allow_html=True)

        if st.button("게임 시작"):
            st.session_state.name_input_mode = True
            st.rerun()

    else:
        # 스타일 설정
        st.markdown("""
        <style>
        textarea {
            color: white !important;
            background-color: #333 !important;
        }
        label, .stMarkdown h4 {
            color: white !important;
        }
        </style>
        """, unsafe_allow_html=True)

        st.markdown("<h4>플레이어 이름을 입력하세요</h4>", unsafe_allow_html=True)

        # 이름 입력
        name = st.text_area("이름 (최대 15자)", max_chars=15, key="player_name")

        # 글자 수 표시
        char_count = len(name)
        st.markdown(
            f"<div style='text-align: right; font-size: 14px; color: #ccc;'>{char_count} / 15자</div>",
            unsafe_allow_html=True
        )

        # 확인 버튼
        if st.button("확인"):
            if name.strip():
                st.session_state.page = "lobby"
                st.rerun()
